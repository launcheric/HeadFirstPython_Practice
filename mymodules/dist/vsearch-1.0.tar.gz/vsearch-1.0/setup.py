from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Eric',
    author_email='hdfew@gmail.com',
    url='sdfeklwa.com',
    py_modules=['vsearch'],
)
